select * from usuario;

select * from empresa;
drop database casamentodossonhos;
/*'10.623.708/0001-52'*/

select * from fotos_empresa;
insert into fotos_empresa(nome_foto, url_foto_empresa, desc_foto, cod_empresa)values("cachorro", "../_imagens/fundo.jpg", "descrição", 1);
select * from categoria;
