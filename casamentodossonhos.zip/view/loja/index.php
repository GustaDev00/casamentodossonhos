<?php
        require_once '../../Db/daohelper.php';
        session_start();
        include_once '../mask/header.html';
        
        include_once 'listaproduto.php';
    
        include_once 'loja.html';

        include_once '../mask/footer.html';
       
          
    ?>